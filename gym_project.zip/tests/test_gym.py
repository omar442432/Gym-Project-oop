"""Automated versions of the 10 test scenarios.  Run from the project folder:  pytest tests"""
import os
import sys
from datetime import date, timedelta

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from gym import Gym, GymError, FileManager  # noqa: E402


@pytest.fixture
def gym() -> Gym:
    g = Gym()
    g.add_member("Ali Hassan", "01012345678")
    return g


def expire(g: Gym) -> None:
    ms = g.memberships[0]
    ms.start = date.today() - timedelta(60)
    ms.end = date.today() - timedelta(1)


# ---- 3 successful scenarios
def test_01_add_member(gym: Gym) -> None:
    assert gym.get_member(1).name == "Ali Hassan"


def test_02_create_membership_records_payment(gym: Gym) -> None:
    gym.create_membership(1, "Monthly")
    assert gym.status_of(1) == "Active"
    assert gym.payments[0].amount == 300


def test_03_attendance_for_active_member(gym: Gym) -> None:
    gym.create_membership(1, "Monthly")
    gym.record_attendance(1)
    assert len(gym.attendance) == 1


# ---- 3 invalid input scenarios
def test_04_empty_name(gym: Gym) -> None:
    with pytest.raises(GymError, match="Name is required"):
        gym.add_member("  ", "01012345678")


def test_05_bad_phone(gym: Gym) -> None:
    with pytest.raises(GymError, match="Phone"):
        gym.add_member("Sara", "abc123")


def test_06_invalid_plan(gym: Gym) -> None:
    with pytest.raises(GymError, match="valid plan"):
        gym.create_membership(1, "Weekly")


# ---- 2 business-rule violations
def test_07_two_active_memberships(gym: Gym) -> None:
    gym.create_membership(1, "Monthly")
    with pytest.raises(GymError, match="already has an active"):
        gym.create_membership(1, "Yearly")


def test_08_attendance_with_expired_membership(gym: Gym) -> None:
    gym.create_membership(1, "Monthly")
    expire(gym)
    with pytest.raises(GymError, match="expired"):
        gym.record_attendance(1)


# ---- 2 edge cases
@pytest.mark.parametrize("amount", [0, -50])
def test_09_payment_not_positive(gym: Gym, amount: float) -> None:
    with pytest.raises(GymError, match="greater than zero"):
        gym.record_payment(1, amount)


def test_10_delete_member_removes_records(gym: Gym) -> None:
    gym.create_membership(1, "Monthly")
    gym.record_attendance(1)
    gym.delete_member(1)
    assert not gym.members and not gym.memberships and not gym.payments and not gym.attendance


# ---- extra: unknown member + file save/load round trip
def test_attendance_unknown_member(gym: Gym) -> None:
    with pytest.raises(GymError, match="does not exist"):
        gym.record_attendance(99)


def test_save_and_load(gym: Gym, tmp_path) -> None:
    gym.create_membership(1, "Quarterly")
    fm = FileManager(str(tmp_path / "gym.json"))
    fm.save(gym.to_dict())
    loaded = Gym.from_dict(fm.load())
    assert loaded.get_member(1).name == "Ali Hassan"
    assert loaded.status_of(1) == "Active"

"""Tkinter GUI for the Gym Management System.  Run:  python main.py"""
import os
import tkinter as tk
from tkinter import messagebox, ttk

from gym import PLANS, FileManager, Gym, GymError


class GymApp(tk.Tk):
    def __init__(self, gym: Gym, fm: FileManager) -> None:
        super().__init__()
        self.title("Gym Management System")
        self.geometry("900x560")
        self.gym, self.fm = gym, fm
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=6, pady=6)
        self.trees, self.member_boxes = {}, []

        self.dash = self._tab("Dashboard")
        self._members_tab()
        self._trainers_tab()
        self._memberships_tab()
        self._payments_tab()
        self._attendance_tab()
        self.refresh()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ------------------------------------------------------------ helpers --
    def _tab(self, name):
        f = ttk.Frame(self.nb)
        self.nb.add(f, text=name)
        return f

    def _row(self, parent):
        f = ttk.Frame(parent)
        f.pack(fill="x", padx=8, pady=4)
        return f

    def _table(self, parent, key, cols):
        tree = ttk.Treeview(parent, columns=cols, show="headings", height=9)
        for c in cols:
            tree.heading(c, text=c)
            tree.column(c, width=110)
        tree.pack(fill="both", expand=True, padx=8, pady=6)
        self.trees[key] = tree
        return tree

    def _entry(self, row, label, width=16):
        var = tk.StringVar()
        ttk.Label(row, text=label).pack(side="left")
        ttk.Entry(row, textvariable=var, width=width).pack(side="left", padx=4)
        return var

    def _box(self, row, values=(), width=28):
        box = ttk.Combobox(row, values=list(values), state="readonly", width=width)
        box.pack(side="left", padx=4)
        return box

    def _member_box(self, row):
        ttk.Label(row, text="Member:").pack(side="left")
        box = self._box(row)
        self.member_boxes.append(box)
        return box

    def _button(self, row, text, action, msg=""):
        ttk.Button(row, text=text, command=lambda: self._do(action, msg)).pack(side="left", padx=2)

    @staticmethod
    def _id(box):
        """'3 - Ahmed' -> 3"""
        if not box.get():
            raise GymError("Please select an item from the list.")
        return int(box.get().split(" - ")[0])

    def _selected(self):
        sel = self.trees["members"].selection()
        if not sel:
            raise GymError("Select a member from the table first.")
        return int(self.trees["members"].item(sel[0])["values"][0])

    def _do(self, action, msg=""):
        """Run action -> save -> refresh -> message. GymError -> error box."""
        try:
            if action() is False:          # action cancelled by the user
                return
            self.fm.save(self.gym.to_dict())
            self.refresh()
            if msg:
                messagebox.showinfo("Done", msg)
        except GymError as e:
            messagebox.showerror("Error", str(e))

    @staticmethod
    def _amount(text):
        try:
            return float(text)
        except ValueError:
            raise GymError("Amount must be a number.")

    # --------------------------------------------------------------- tabs --
    def _members_tab(self):
        t, g = self._tab("Members"), self.gym
        top = self._row(t)
        self.search = self._entry(top, "Search:", 20)
        self.status = tk.StringVar(value="All")
        ttk.Combobox(top, textvariable=self.status, state="readonly", width=14,
                     values=["All", "Active", "Expired", "No Membership"]).pack(side="left", padx=4)
        ttk.Button(top, text="Search / Filter", command=self.refresh).pack(side="left")

        tree = self._table(t, "members", ("ID", "Name", "Phone", "Status", "Trainer"))
        tree.bind("<<TreeviewSelect>>", self._on_select)

        form = self._row(t)
        self.name, self.phone = self._entry(form, "Name:", 20), self._entry(form, "Phone:")
        self._button(form, "Add", lambda: g.add_member(self.name.get(), self.phone.get()), "Member added.")
        self._button(form, "Update", lambda: g.update_member(self._selected(), self.name.get(),
                                                             self.phone.get()), "Member updated.")
        self._button(form, "Delete", self._delete, "Member deleted.")

        assign = self._row(t)
        ttk.Label(assign, text="Assign trainer to selected member:").pack(side="left")
        self.trainer_box = self._box(assign, width=30)
        self._button(assign, "Assign", lambda: g.assign_trainer(self._selected(), self._id(self.trainer_box)),
                     "Trainer assigned.")

    def _on_select(self, _e):
        try:
            m = self.gym.get_member(self._selected())   # read from model (keeps leading zeros)
            self.name.set(m.name)
            self.phone.set(m.phone)
        except GymError:
            pass

    def _delete(self):
        if not messagebox.askyesno("Confirm", "Delete the selected member and all their records?"):
            return False
        self.gym.delete_member(self._selected())

    def _trainers_tab(self):
        t, g = self._tab("Trainers"), self.gym
        self._table(t, "trainers", ("ID", "Name", "Phone", "Specialty"))
        form = self._row(t)
        n, p, s = self._entry(form, "Name:", 18), self._entry(form, "Phone:"), self._entry(form, "Specialty:")
        self._button(form, "Add Trainer", lambda: g.add_trainer(n.get(), p.get(), s.get()), "Trainer added.")

    def _memberships_tab(self):
        t, g = self._tab("Memberships"), self.gym
        top = self._row(t)
        box = self._member_box(top)
        plan = self._box(top, PLANS, 12)
        plan.set("Monthly")
        self._button(top, "Create", lambda: g.create_membership(self._id(box), plan.get()),
                     "Membership created (payment recorded).")
        self._button(top, "Renew", lambda: g.renew_membership(self._id(box), plan.get()),
                     "Membership renewed (payment recorded).")
        self._table(t, "memberships", ("ID", "Member", "Plan", "Start", "End", "Price", "Status"))

    def _payments_tab(self):
        t, g = self._tab("Payments"), self.gym
        top = self._row(t)
        box = self._member_box(top)
        amount = self._entry(top, "Amount:", 10)
        self._button(top, "Record Payment",
                     lambda: g.record_payment(self._id(box), self._amount(amount.get())), "Payment recorded.")
        self._table(t, "payments", ("Member", "Amount", "Date", "Note"))

    def _attendance_tab(self):
        t, g = self._tab("Attendance"), self.gym
        top = self._row(t)
        box = self._member_box(top)
        self._button(top, "Check In", lambda: g.record_attendance(self._id(box)), "Attendance recorded.")
        self._table(t, "attendance", ("Member", "Date"))

    # ------------------------------------------------------------ refresh --
    def _fill(self, key, rows):
        tree = self.trees[key]
        tree.delete(*tree.get_children())
        for r in rows:
            tree.insert("", "end", values=r)

    def refresh(self):
        g = self.gym
        for w in self.dash.winfo_children():
            w.destroy()
        for i, (k, v) in enumerate(g.dashboard().items()):
            card = ttk.LabelFrame(self.dash, text=k)
            card.grid(row=i // 3, column=i % 3, padx=12, pady=12, sticky="nsew")
            ttk.Label(card, text=str(v), font=("Arial", 22, "bold")).pack(padx=30, pady=15)

        self._fill("members", [(m.id, m.name, m.phone, g.status_of(m.id), g.trainer_name(m.trainer_id))
                               for m in g.search_members(self.search.get(), self.status.get())])
        self._fill("trainers", [(t.id, t.name, t.phone, t.specialty) for t in g.trainers])
        self._fill("memberships", [(s.id, g.member_name(s.member_id), s.plan, s.start, s.end, s.price,
                                    "Active" if s.is_active else "Expired") for s in g.memberships])
        self._fill("payments", [(g.member_name(p.member_id), f"{p.amount:.2f}", p.day, p.note)
                                for p in g.payments])
        self._fill("attendance", [(g.member_name(a.member_id), a.day) for a in g.attendance])

        for box in self.member_boxes:                    # polymorphism: label()
            box["values"] = [m.label() for m in g.members]
        self.trainer_box["values"] = [t.label() for t in g.trainers]

    def _on_close(self):
        try:
            self.fm.save(self.gym.to_dict())
        except GymError as e:
            messagebox.showerror("Error", str(e))
        self.destroy()


def main() -> None:
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "gym.json")
    fm = FileManager(path)
    try:
        gym = Gym.from_dict(fm.load())
    except GymError as e:
        print(e)
        gym = Gym()
    GymApp(gym, fm).mainloop()


if __name__ == "__main__":
    main()
